# Project name: Seat_Arranger

This is a random arrangement program aimming to randomize seating arrangement of any table-like seating format.

# Suitable scenario:
e.g.: if your seating layout is like:\
[],[],...,[],...,[],[]\
[],[],...,[],...,[],[]\
...\
[],[],...,[],...,[],[]\
Then this project can be useful to you.


# Environment:
No extra environment setting is requiered.

# How to run:
- Linux: run "./dist/driver" under the main directory\
- Window: no supporting yet\
- Mac: no supporting yet

# How to use (After run)




# 项目名称：随机排座

简介：这是一个基于python，并利用pyqt进行可视化的排座位程序，适用于任意表格化座位分布的随机排座场景。
比方说，如果你的座位表形如以下格式：\
[],[],...,[],...,[],[]\
[],[],...,[],...,[],[]\
...\
[],[],...,[],...,[],[]\
而你希望将一定人员在这个空间中随机排序分配座位，那么这个项目可能可以帮到你

# 环境需求
没有额外的环境需求，下载即用

# 运行方法：
- Linux：运行同目录下dist中driver文件。命令行命令为："./dist/driver"\
- Windows：尚不支持\
- Mac：尚不支持





