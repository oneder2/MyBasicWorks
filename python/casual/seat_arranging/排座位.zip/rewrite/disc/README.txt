请运行 "runme.exe" 来运行程序。
学生姓名列表可以是 ".csv" 或 ".txt" 文件。
.csv 文件要求有一列姓名，并以 "name" 作为标题(head)。
.txt 文件要求每个姓名后面跟一个换行符。
要查看具体格式，请查看 "example" 目录。

关于这个项目的github地址：
https://github.com/oneder2/Seat_Arranger
我会继续更新的（大概）
届时请下载windows分支下的内容
不会用git也没关系，现在github可以直接下载压缩包，方便极了


I am running windows on virtual machine(specifically, Virtual Box). So I cannot(just lazy to) type Chinese. Forgive me for this rigid translation by AI.

By the way, if some of you grant yourself as an IT man, and is passionate about create or fix sth about information tech, I highly recommend you to use Linux. If you are not sure how to begin, try Virtual Box and set up a Linuxmint virtual machine.

I know there is several bugs, especially when it comes to some exceptions, like if you choose a right life, yet no column number input, there will be error for both file path and column input. I 100% understand if random people believe my code is a shit mountain - it is. So any of you are willing to fix it, I will be never more appreciate about it(But make sure you won't fall behind that much first).

High school days, sounds pretty nostalgia.

好的我回到linux主机上了，像回家了一样。

